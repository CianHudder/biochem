//set variables
var bioButton = document.getElementById('bioButton');
var chemButton = document.getElementById('chemButton');
var physButton = document.getElementById('physButton');
var subunitTitle = document.getElementsByClassName("SubunitTitle");
var n = -1;

//debug variable 
var test;

// this is our button function to display the correct text
function updateText () {


    // hides sources and current questions
    if (n != -1) {
        document.getElementById('Sources').style.display = "none";
        document.getElementById('Current-Questions').style.display = "none";
    }

    //bio units
    if (n===0){
        document.getElementById('Biochemistry').style.display = "block";  
    } else {document.getElementById('Biochemistry').style.display = "none";}
    if (n===1) {
        document.getElementById('Molecular-Biology').style.display = "block";
    } else {document.getElementById('Molecular-Biology').style.display = "none";}
    if (n===2) {
        document.getElementById('Genetics').style.display = "block";
    } else {document.getElementById('Genetics').style.display = "none";}
    if (n===3) {
        document.getElementById('Homeostasis').style.display = "block";
    } else {document.getElementById('Homeostasis').style.display = "none";}

    //chem units
    if (n===4){
        document.getElementById('Organic-Chemistry').style.display = "block";  
    } else {document.getElementById('Organic-Chemistry').style.display = "none";}
    if (n===5) {
        document.getElementById('Atomic-Chemistry').style.display = "block";
    } else {document.getElementById('Atomic-Chemistry').style.display = "none";}
    if (n===6) {
        document.getElementById('Equilibrium').style.display = "block";
    } else {document.getElementById('Equilibrium').style.display = "none";}
    if (n===7) {
        document.getElementById('Thermodynamics').style.display = "block";
    } else {document.getElementById('Thermodynamics').style.display = "none";}
    if (n===8) {
        document.getElementById('Electrochemistry').style.display = "block";
    } else {document.getElementById('Electrochemistry').style.display = "none";}

    //phys units
    if (n===9) {
        document.getElementById('Quantum-Mechanics').style.display = "block";
    } else {document.getElementById('Quantum-Mechanics').style.display = "none";}

    //change colors based on subject
    if (n<9 && n>3) {
        document.getElementsByClassName("UnitTitle")[n].style.backgroundColor = "#4e4ad9";
        for (var k=0; k<subunitTitle.length; k++) {
            subunitTitle[k].style.backgroundColor = "#6563f7";
            console.log("g");
        }
    }
    if (n>8) {
        document.getElementsByClassName("UnitTitle")[n].style.backgroundColor = "#cc253b";
        for (var j=0; j<subunitTitle.length; j++) {
            subunitTitle[j].style.backgroundColor = "#992e3c";
            console.log("g");
        }   
    }
    if (n<4 || isNaN(n)) {
        document.getElementsByClassName("UnitTitle")[n].style.backgroundColor = "#00fa9a";
        for (var i=0; i<subunitTitle.length; i++) {
            subunitTitle[i].style.backgroundColor = "#5aedb5";
            console.log("g");

        }
        

    }

}